# Changelog

## 0.40 - 2023-01-21

`NameMode` added

Commands for updating settings added

## 0.03 - 2023-01-07

Fixed defect preventing loading from startup scripts

## 0.02 - 2023-01-03

`HideStars` added

## 0.01 - 2022-09-30

Initial release
