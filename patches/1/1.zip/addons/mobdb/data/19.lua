--Zone: Spire of Dem
--Zone ID: 19
return {
    Names = {
        ['Ingester'] = { Name='Ingester', Notorious=false, Aggro=true, Link=true, TrueSight=true, Job=0, MinLevel=0, MaxLevel=0, Immunities=0, Respawn=0, Sight=true, Sound=false, Blood=false, Magic=false, JA=false, Scent=false, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1, Wind=1, Earth=1, Lightning=1, Water=1, Light=1, Dark=1} },
        ['Neogorger'] = { Name='Neogorger', Notorious=false, Aggro=true, Link=true, TrueSight=true, Job=0, MinLevel=0, MaxLevel=0, Immunities=0, Respawn=0, Sight=true, Sound=false, Blood=false, Magic=false, JA=false, Scent=false, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1, Wind=1, Earth=1, Lightning=1, Water=1, Light=1, Dark=1} },
        ['Neoingester'] = { Name='Neoingester', Notorious=false, Aggro=true, Link=true, TrueSight=true, Job=0, MinLevel=0, MaxLevel=0, Immunities=0, Respawn=0, Sight=true, Sound=false, Blood=false, Magic=false, JA=false, Scent=false, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1, Wind=1, Earth=1, Lightning=1, Water=1, Light=1, Dark=1} },
        ['Neosatiator'] = { Name='Neosatiator', Notorious=false, Aggro=true, Link=true, TrueSight=true, Job=0, MinLevel=0, MaxLevel=0, Immunities=0, Respawn=0, Sight=true, Sound=false, Blood=false, Magic=false, JA=false, Scent=false, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1, Wind=1, Earth=1, Lightning=1, Water=1, Light=1, Dark=1} },
        ['Offspring'] = { Name='Offspring', Notorious=false, Aggro=true, Link=true, TrueSight=true, Job=0, MinLevel=27, MaxLevel=28, Immunities=1, Respawn=0, Sight=false, Sound=false, Blood=false, Magic=false, JA=false, Scent=true, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1, Wind=1, Earth=1, Lightning=1, Water=1, Light=1, Dark=1} },
        ['Progenerator'] = { Name='Progenerator', Notorious=false, Aggro=true, Link=false, TrueSight=true, Job=0, MinLevel=37, MaxLevel=38, Immunities=5, Respawn=0, Sight=true, Sound=false, Blood=false, Magic=false, JA=false, Scent=false, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1, Wind=1, Earth=1, Lightning=1, Water=1, Light=1, Dark=1} },
        ['Wanderer'] = { Name='Wanderer', Notorious=false, Aggro=true, Link=false, TrueSight=true, Job=0, MinLevel=0, MaxLevel=0, Immunities=0, Respawn=0, Sight=false, Sound=true, Blood=false, Magic=false, JA=false, Scent=false, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1, Wind=1, Earth=1, Lightning=1, Water=1, Light=1, Dark=1} },
    },
    Indices = {
    },
};