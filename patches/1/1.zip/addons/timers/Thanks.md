I would be remiss if I did not express my gratitude to the following people
for sharing their extensive knowledge on Ashita's discord, and being very
patient with me and my sometimes ignorant questions.

Without every one of these people, this addon would not be possible.

Thorny - For creating the durations library that my code depends on, and for
         patiently answering all my questions, and providing input and code
         for some of the more difficult parts.

atom0s - For creating Ashita in the first place (Thorny too), and for his
         thorough answer to questions I asked when things seems broken or
         I just couldn't find the answer on my on.

Heals  - For providing many examples, and always being ready to discuss a
         problem and offer input.  Also for the helpers.lua file that I
         shamelessly ripped out of her StatusTimers addon.
